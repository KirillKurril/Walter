﻿using _253504_dmi_Lab5.Collections;
using _253504_dmi_Lab5.Entities;
using System;

namespace _253504_dmi_Lab5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            MyCustomCollection<int> arr = new MyCustomCollection<int>();
            arr.Add(1); 
            arr.Add(2);
            arr.Add(3);
            arr.Add(4);
            arr.Add(5);
            foreach (int i in arr)
            {
                Console.WriteLine(i);
            }
            try
            {
                arr.Remove(10);
            }
            catch (CustomException ex)
            {
                Console.WriteLine($"Ошибка: {ex.Message}");
                Environment.Exit(1);
            }

        }
    }
}