﻿using System;

namespace _253504_dmi_Lab5.Entities
{
    public class CustomException : Exception
    {
        public CustomException(string message = "Удаляемый элемент не найден!") : base(message) 
        { }
    }
}

